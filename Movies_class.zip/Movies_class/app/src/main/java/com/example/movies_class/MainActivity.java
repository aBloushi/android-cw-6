package com.example.movies_class;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Movie Avengers_endgame = new Movie("Avengers Endgame","Robert Downey Jr",8.4,13 , "Action");
        Movie Inception  = new Movie("Inception ","Leonardo DiCaprio",8.8,13 , "Action");
    }
}